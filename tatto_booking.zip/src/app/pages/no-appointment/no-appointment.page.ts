import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-appointment',
  templateUrl: './no-appointment.page.html',
  styleUrls: ['./no-appointment.page.scss'],
})
export class NoAppointmentPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
