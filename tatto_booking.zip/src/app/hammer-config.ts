export class HammerConfig {
}
