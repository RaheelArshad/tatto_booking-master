import { ModalController } from '@ionic/angular';
import { SearchModalPage } from './../search-modal/search-modal.page';
import { Component, OnInit } from '@angular/core';
import {ApiService} from '../services/api.service';

@Component({
  selector: 'app-main',
  templateUrl: './main.page.html',
  styleUrls: ['./main.page.scss'],
})
export class MainPage implements OnInit {

  card1 = false;
  card2 = false;
  card3 = false;
  imgUrl = 'http://54.93.192.116/barber/adminpanel/public/storage/images/categories/';
  saloonImgUrl = 'http://54.93.192.116/barber/adminpanel/public/storage/images/salon%20logos/';
  tattoos: any = [];
  finalTattoos: any = [];
  shops: any = [];
  finalShops: any = [];
  constructor(private modalController: ModalController, private Api: ApiService) {
    this.Api.getCategories().subscribe((data: any) => {
      this.tattoos = data.data;
    });
    this.Api.getSaloons().subscribe((data: any) => {
      console.log(data);
      this.shops = data.data;
    });
  }

  tattooSearch(event) {
    const val = event.target.value;
    let newTqattoo = this.tattoos;
    newTqattoo = newTqattoo.filter((item) => {
      return (item.name.toLowerCase().indexOf(val.toLowerCase()) > -1);
    });
    let finalTattoo = newTqattoo;
    finalTattoo = finalTattoo.filter((item) => {
      // console.log(item);
      return (item.name.toLowerCase().indexOf('tattoo'.toLowerCase()) > -1);
    });
    this.finalTattoos = finalTattoo;
  }
  shopSearch(event) {
    const val = event.target.value;
    let newShops = this.shops;
    newShops = newShops.filter((item) => {
      return (item.name.toLowerCase().indexOf(val.toLowerCase()) > -1);
    });
    this.finalShops = newShops;
  }

  Card1()
  {
    if (this.card2 == false && this.card3 == false)
    {
      this.card1 =! this.card1;
    }
    else
    {
      this.card1 = false;
    }
  }
    Card2()
    {
      if(this.card1 === false && this.card3 === false)
      {
        this.card2 =!this.card2;
      }
      else
      {
        this.card2 = false;
      }
    }

    Card3()
    {
      if (this.card1 === false && this.card2 === false)
      {
        this.card3 =!this.card3;
      }
      else
      {
        this.card3 = false;
      }
    }

    async presentModal() {
      const modal = await this.modalController.create({
        component: SearchModalPage,
        cssClass: 'searchModal',
      });
      return await modal.present();
    }


  ngOnInit() {
  }

}
