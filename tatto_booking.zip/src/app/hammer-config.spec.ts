import { HammerConfig } from './hammer-config';

describe('HammerConfig', () => {
  it('should create an instance', () => {
    expect(new HammerConfig()).toBeTruthy();
  });
});
